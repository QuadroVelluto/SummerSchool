#!/bin/bash

script_name=$(basename "$0")
if [[ "$script_name" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

log_file="report_${script_name}.log"
pid=$$
start_time=$(date '+%Y-%m-%d %H:%M:%S')

echo "[$pid] $start_time Скрипт запущен" >> "$log_file"

sleep_time=$(( RANDOM % 1771 + 30 ))
sleep "$sleep_time"

end_time=$(date '+%Y-%m-%d %H:%M:%S')
minutes=$(( sleep_time / 60 ))

echo "[$pid] $end_time Скрипт завершился, работал $minutes минут" >> "$log_file"

