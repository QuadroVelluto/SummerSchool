#!/bin/bash

config_file="observer.conf"
log_file="observer.log"

while read -r script; do
    [ -z "$script" ] && continue 
    script_name=$(basename "$script")

    if ! pgrep -f "$script_name" > /dev/null; then
        nohup "$script" > /dev/null 2>&1 &
        echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапущен: $script_name" >> "$log_file"
    fi
done < "$config_file"

